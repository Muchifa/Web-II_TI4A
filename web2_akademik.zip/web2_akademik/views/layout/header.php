<!DOCTYPE html>
<html>
<head>

<title>WEB 2 MVC</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>