<?php include 'views/layout/header.php'; ?>
<!-- ?php include 'views/layouts/sidebar_admin.php'; ?> -->

<div class="col-md-10 p-4">
    <h3>Edit Mahasiswa</h3>

    <form method="post" action="index.php?page=mahasiswa&aksi=update">
        <input type="hidden" name="id" value="<?= $row['id'] ?>">
        <input type="text" name="nim" class="form-control mb-2"
               value="<?= $row['nim'] ?>" required>
        <input type="text" name="nama" class="form-control mb-2"
               value="<?= $row['nama'] ?>" required>
        <input type="email" name="email" class="form-control mb-3"
               value="<?= $row['email'] ?>" required>
        <button class="btn btn-primary">Update</button>
        <a href="index.php?page=mahasiswa" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include 'views/layout/footer.php'; ?>