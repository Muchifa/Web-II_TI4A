<?php require 'views/layout/header.php'; ?>
<?php require 'views/layout/navbar.php'; ?>

<h2>Edit Tugas</h2>

<form method="POST" action="index.php?page=update_tugas">

<input type="hidden" name="id" value="<?php echo $data['id']; ?>">

<div class="mb-3">
<label>Judul</label>
<input type="text" name="judul" class="form-control"
value="<?php echo $data['judul']; ?>">
</div>

<div class="mb-3">
<label>Deskripsi</label>
<textarea name="deskripsi" class="form-control"><?php echo $data['deskripsi']; ?></textarea>
</div>

<div class="mb-3">
<label>Deadline</label>
<input type="date" name="deadline" class="form-control"
value="<?php echo $data['deadline']; ?>">
</div>

<button class="btn btn-primary">Update</button>

<a href="index.php?page=tugas" class="btn btn-secondary">
Kembali
</a>

</form>

<?php require 'views/layout/footer.php'; ?>