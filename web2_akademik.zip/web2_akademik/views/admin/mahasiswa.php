<?php require 'views/layout/header.php'; ?>
<?php require 'views/layout/navbar.php'; ?>

<h2>Data Mahasiswa</h2>

<a href="index.php?page=tambah_mahasiswa" class="btn btn-primary mb-3">
Tambah Mahasiswa
</a>

<table class="table table-bordered">

<tr>
<th>No</th>
<th>NIM</th>
<th>Nama</th>
<th>Email</th>
<th>Aksi</th>
</tr>

<?php
$no=1;
foreach($mahasiswa as $m){
?>

<tr>
<td><?php echo $no++; ?></td>
<td><?php echo $m['nim']; ?></td>
<td><?php echo $m['nama']; ?></td>
<td><?php echo $m['email']; ?></td>

<td>
<a href="index.php?page=edit_mahasiswa&id=<?php echo $m['id']; ?>" class="btn btn-warning btn-sm">Edit</a>

<a href="index.php?page=hapus_mahasiswa&id=<?php echo $m['id']; ?>" class="btn btn-danger btn-sm">Hapus</a>
</td>

</tr>

<?php } ?>

</table>

<?php require 'views/layout/footer.php'; ?>