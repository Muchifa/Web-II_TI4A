<!-- Models/Tugas.PHP -->

<?php

require_once "config/database.php";

class Tugas{

    public function getAll(){

        global $koneksi;

        $query = mysqli_query($koneksi,"SELECT * FROM tugas");

        $data = [];

        while($row = mysqli_fetch_assoc($query)){
            $data[] = $row;
        }

        return $data;
    }

    public function insert($judul,$deskripsi,$deadline){

        global $koneksi;

        mysqli_query($koneksi,"INSERT INTO tugas(judul,deskripsi,deadline)
        VALUES('$judul','$deskripsi','$deadline')");

    }

}
?>