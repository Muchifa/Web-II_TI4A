<!-- Models/Mahasiswa.PHP -->

<?php

require_once "config/database.php";

class Mahasiswa{

    public function getAll(){

        global $koneksi;

        $query = mysqli_query($koneksi,"SELECT * FROM mahasiswa");

        $data = [];

        while($row = mysqli_fetch_assoc($query)){
            $data[] = $row;
        }

        return $data;
    }

    public function insert($nim,$nama,$email){

        global $koneksi;

        mysqli_query($koneksi,"INSERT INTO mahasiswa(nim,nama,email)
        VALUES('$nim','$nama','$email')");

    }

}
?>