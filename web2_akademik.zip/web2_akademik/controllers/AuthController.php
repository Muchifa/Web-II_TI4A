<?php

require_once 'config/database.php';

class AuthController {

    public function login(){

        $username = $_POST['username'];
        $password = $_POST['password'];

        $query = mysqli_query($GLOBALS['koneksi'],
            "SELECT * FROM users WHERE username='$username'"
        );

        $user = mysqli_fetch_assoc($query);

        if($user){

            if(password_verify($password,$user['password'])){

                $_SESSION['login'] = true;
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];

                header("Location: index.php?page=dashboard");
                exit;

            }else{

                header("Location: index.php?page=login&error=password");
                exit;

            }

        }else{

            header("Location: index.php?page=login&error=username");
            exit;

        }

    }

}