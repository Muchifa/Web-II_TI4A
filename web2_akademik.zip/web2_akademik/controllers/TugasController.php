<?php

require_once "models/Tugas.php";

class TugasController{

    public function index(){

        $model = new Tugas();

        // ambil semua data tugas
        $tugas = $model->getAll();

        require "views/admin/tugas.php";
        require "views/layout/footer.php";
    }

    public function tambah(){

        require "views/admin/tugas_tambah.php";
        require "views/layout/footer.php";
    }

    public function simpan(){

        $model = new Tugas();

        $judul       = $_POST['judul'];
        $deskripsi   = $_POST['deskripsi'];
        $deadline    = $_POST['deadline'];

        $model->insert($judul,$deskripsi,$deadline);

        header("Location: index.php?page=tugas");
        exit;
    }

}
?>