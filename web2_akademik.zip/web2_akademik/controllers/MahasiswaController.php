<?php

require_once "models/Mahasiswa.php";

class MahasiswaController{

    public function index(){

        $model = new Mahasiswa();

        // ambil data mahasiswa dari model
        $mahasiswa = $model->getAll();

        // tampilkan view
        require "views/admin/mahasiswa.php";
        require "views/layout/footer.php";

    }

    public function tambah(){

        require "views/admin/mahasiswa_tambah.php";
        require "views/layout/footer.php";

    }

    public function simpan(){

        $model = new Mahasiswa();

        $nim   = $_POST['nim'];
        $nama  = $_POST['nama'];
        $email = $_POST['email'];

        $model->insert($nim,$nama,$email);

        header("Location: index.php?page=mahasiswa");
        exit;

    }

}
?>