<?php

class AdminController{

    public function dashboard(){

        // cek apakah user login
        if(!isset($_SESSION['login'])){
            header("Location: login.php");
            exit;
        }

        // cek apakah role admin
        if($_SESSION['role'] != "admin"){
            echo "Akses ditolak";
            exit;
        }

        // load tampilan dashboard
        require_once "views/layout/header.php";
        require_once "views/admin/dashboard.php";
        require_once "views/layout/footer.php";

    }

}
?>

<?php
require 'views/admin/dashboard.php';