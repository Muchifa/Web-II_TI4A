<?php
require 'config/database.php';
require 'models/User.php';

$user = new User($koneksi);
$aksi = $_GET['aksi'] ?? 'index';

switch ($aksi) {

    case 'index':
        $data = $user->db();
        require 'views/admin/mahasiswa.php';
        break;

    case 'tambah':
        require 'views/admin/mahasiswa_tambah.php';
        break;

    case 'simpan':
        $mahasiswa->insert($_POST['id'], $_POST['nim'], $_POST['nama'], $_POST['email']);
        header("Location: index.php?page=mahasiswa");
        break;

    case 'edit':
        $id = $_GET['id'];
        $data = $mahasiswa->find($id);
        $row = mysqli_fetch_assoc($data);
        require 'views/admin/mahasiswa_edit.php';
        break;

    case 'update':
        $mahasiswa->update($_POST['id'], $_POST['nim'], $_POST['nama'], $_POST['email']);
        header("Location: index.php?page=mahasiswa");
        break;

    case 'hapus':
        $user->delete($_GET['id']);
        header("Location: index.php?page=mahasiswa");
        break;
}

?>